# Name: Joshua Kettlehake
# Project 6
# This is the hangman program.
# The words for this game are found in a file named wordlist.txt
# This file was not provided to me, so I created it from a list I found using Google

# To randomize the words for game use
import random
# Initializing wordlist.txt file
wordListFile = "wordlist.txt"
# Initializing wordlist.txt dictionary
wordList = dict()

# Initialing dictionary with keys and empty list
# For words with length 3 to 14(longest word is representative)
for i in range(13):
    wordList[i + 3] = []

# Reading in wordlist.txt
try:
    with open(wordListFile) as inFile:
        for line in inFile:
            for word in line.split():
                # Removing \n from each word
                word = word.rstrip("\n")
                # Taking only words with length 3 to 14
                if(len(word) in range(3, 14)):
                    wordList[len(word)].append(word)

    print("Welcome to hangman.")
    print("You may pick word lengths from 3 to 14 characters.")

    # initializing valid to False for verification
    isValid = False

    # Loops until user inputs valid integer input
    while(isValid == False):
        # User inputs word length
        wordLength = input("Enter a number between 3 and 14 (inclusive) to determine word length here ---> ")
        # Validating user input
        try:
            wordLength = int(wordLength)
            isValid = True
            # Validated if input is in range 3 to 14
            if(wordLength not in range(3, 15)):
                print("Out of range... ")
                isValid = False
        # Throw this error if the input is not an integer
        except ValueError:
            print("Invalid input. Please try again...")
            isValid = False

    #Picks word from dictionary
    rangeRandom = len(wordList[wordLength])
    randomPick = random.randrange(0, rangeRandom)
    wordToGuess = wordList[wordLength][randomPick]

    print(wordToGuess) # comment this out when playing for reals... for keeps...

    # Initializing number of guesses allowed(2n - 1)
    numGuesses = (wordLength * 2 - 1)
    # To determine if word is guessed correctly(or not)
    isCorrect = False
    # Temporary word for hiding the word from user
    tempWord = '*' * len(wordToGuess)
    # List of guesses already attempted
    attemptedGuesses = []

    # Loops until the number of allowed guesses is reached or word is guessed correctly
    while(numGuesses > 0 and isCorrect == False):
        # Decrement number of guesses
        numGuesses = numGuesses - 1
        # Number of correct letters of word
        numLettersCorrect = 0
        # Prints the word with *s and correct letters guessed
        print("\nWord: ", end='')
        print(tempWord)
        # Prints number of guesses remaining
        print("After this, you will have %s guesses remaining." % numGuesses)
        # Asks user for a letter or word
        userGuess = input("Type a letter or a word to guess: ")
        # Converts user input to lowercase for validating
        userGuess = userGuess.lower()
        # Checking if user input has already been attempted

        while userGuess in attemptedGuesses:
            print("You have already tried this guess. Please try again...")
            userGuess = input("Type a letter or a word to guess: ")
        # Loops to validate input
        # Will continue to look until user enters input in correct format

        while userGuess.isalpha() == False:
            print("Invalid input. Please try again...")
            userGuess = input("Type a letter or a word to guess: ")
        # Adds validated input to attemptedGuesses
        attemptedGuesses.append(userGuess)
        # Determines if user input is letter or word

        if(len(userGuess) >= 2):
            # If correct, then user wins
            if(userGuess == wordToGuess):
                print("\nCongratulations! You are correct!")
                isCorrect = True
            else:
                print("The word is not '" + userGuess + ".'")
        else:
            # Checks if letter is in word
            for i in range(len(wordToGuess)):
                if userGuess == wordToGuess[i]:
                    numLettersCorrect = numLettersCorrect + 1
                    tempWord = tempWord[:i] + wordToGuess[i] + tempWord[i + 1:]
            # Prints number of letters user has guessed correctly
            if (numLettersCorrect == 1):
                print("There is 1 %s." % userGuess)
            elif (numLettersCorrect >= 2):
                print("There are %s %ss." % (numLettersCorrect, userGuess))
            else:
                print("Sorry, there is no %s." % userGuess)
            # Checks if user has guessed correctly
            if(tempWord == wordToGuess):
                print("\nCongratulations! You win!")
                isCorrect = True

    # Checks if word not guessed(with statement)
    if not isCorrect:
        print("\nYou lose...")
        # Prints wordToGuess
        print("The word was %s." % wordToGuess)

    # Game over statement
    print("Game over...")
# Throws error if wordlist.txt does not exist(with system exit)
except IOError:
    print("File does not exist...")
# Exits the program
finally:
    exit()
