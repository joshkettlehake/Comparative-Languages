# Name: Joshua Kettlehake
# Project 7
# This is the Student Records program
# The studentRecordsIn.txt will be read from
# The program will create a Student object for each Student in the file
# The program will write to the standard output and to a new text file (studentRecordsOutput)

# Creates Student objects with uid, first, last, level, and classes
# Returns a new Student object
class Student:
    # Initializing Students information
    def __init__(self, uid, firstName, lastName, level):
        # Initializing parameter values
        self.uid = uid
        self.firstName = firstName
        self.lastName = lastName
        self.level = level
        self.classes = []

    # Adding a new class
    def addClasses(self, newClass):
        # Appends newClass to classes array
        self.classes.append(newClass)

    # Overrides the print method
    def __str__(self):
        # Formatting the output string
        result = 'UID: {self.uid} \nFirst Name: {self.firstName} \nLast Name: {self.lastName} \nLevel: {self.level}'.format(self=self)
        result += '\nCLASSES: \n'
        # Loops through classes array
        for course in self.classes:
            result += course + '\n'
        # Return result for printing
        return result

# Defining Filename to be read from

inputFile = "studentRecordsIn.txt"

# Array for Student objects
studentRecords = []

# Try-catch for file i/o safety
try:
    # Opens inputFile
    with open(inputFile) as inFile:

        # Iterates through file
        for line in inFile:
            # Temporary variables for Student information
            count = 0
            uid = ""
            fname = ""
            lname = ""
            level = ""
            classes = []

            # Iterates through the line to get each individual part
            for data in line.split():
                # Count to determine where the pointer is in the line
                # Assigning received input to corresponding variables
                if(count == 0):
                    uid = data
                elif(count == 1):
                    fname = data
                elif(count == 2):
                    lname = data
                elif(count == 3):
                    level = data
                else:
                    classes.append(data)
                # Increment counter
                count += 1

            # Creates Student object fpr each line of file
            student = Student(uid, fname, lname, level)

            # Iterates through classes array (cannot use class in classes)
            for course in classes:
                student.addClasses(course)

            # Appending each student into studentRecords array
            studentRecords.append(student)

        # Printing student records to console
        print("Student Records\n\n")
        # Loop through student records and print each student
        # Uses override of __str__ to print students
        for student in studentRecords:
            print(student)

        # Opens or creates outputFile
        with open('studentRecordsOutput.txt', 'w') as outputFile:
            # Writing to outputFile
            outputFile.write("Student Records\n\n")

            # Iterates through studentRecords array
            # Writes to outputFile using override of __str__
            for student in studentRecords:
                outputFile.write(student.__str__())
                outputFile.write('\n')

# Throws error if file does not exist
except IOError:
    print("File does not exist. \nProgram will exit now.")

# Exits program
finally:
    exit()
